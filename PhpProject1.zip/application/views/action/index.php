
<!--<?php if(mktime() < $this->config->item('con_finish')) 
            {?>
 <div style="margin-bottom: 30px; margin-top: 30px;" class="box_skitter box_skitter_large">
    <ul >
        <li>
            <a href="<?php echo base_url(); ?>index.php/action/terms"><img src="http://nashpilot.ru/upload/an/11.jpg"/></a>
        </li>
        <li>
                <a href="<?php echo base_url(); ?>index.php/action/terms"><img src="http://nashpilot.ru/upload/an/22.jpg"/></a>
        </li>
        <li>
                <a href="<?php echo base_url(); ?>index.php/action/terms"><img src="http://nashpilot.ru/upload/an/33.jpg"/></a>
        </li>
        <li>
                <a href="<?php echo base_url(); ?>index.php/action/terms"><img src="http://nashpilot.ru/upload/an/44.jpg"/></a>
        </li>
    </ul>
</div>
<h1 style="text-align:center;">��������� �����</h1>
<?php } ?>-->
<?php if(mktime() > $this->config->item('con_finish')) { ?>
    <h1 style="text-align: center; margin-bottom: 40px; font-size: 40px; color: #CF3200; font-family: calibri;">���������� ��������</h1>
<?php } ?>
<div class="actions">
 <table>
     <?php 
              
     
        $i = 0;
        $m = 0;
        $l = 0;
        foreach($query as $item){
            
             $urli = base_url().substr($item->image_url, 0, strlen($item->image_url) - 4)."_thumb".substr($item->image_url, strlen($item->image_url) - 4, strlen($item->image_url));
               $size = getimagesize($urli);
               $bgpos = '';
                    if($size[0] > $size[1])
                           $bgpos = '50%';
                    else
                           $bgpos = '0%';
            
            $m++;
            $tpolls = "";
            $spolls = substr($item->count_poll, strlen($item->count_poll)-1, strlen($item->count_poll));
            $opolls = substr($item->count_poll, strlen($item->count_poll)-2, strlen($item->count_poll));
            if ($spolls == 1)
            {
                 if($opolls == 11)
                {
                    $tpolls = "�������";
                }
                else{
                    $tpolls = "�����";
                }
            }
            else if ($spolls == 2 or $spolls == 3 or $spolls == 4)
            {
                if($opolls == 12 or $opolls == 13 or $opolls == 14)
                {
                    $tpolls = "�������";   
                }
                else{
                    $tpolls = "������";
                }
            }
            else
            {
                $tpolls = "�������";
            }
            
             if((mktime() > $this->config->item('con_finish')) & ($m < 4))
            {
                 ?>
                 
     
             
                 <?php if ($m==1) { ?>
                 <tr><td colspan="3">
                         <div id="prisers">
                             <div class="priser1">
                     <div class="photo">
                         <a class="member-link" href="<?php echo base_url(); ?>index.php/action/member/<?php echo $item->idAction; ?>">
                             <div class="bg-img-member"><div class="img" style="background-position: 50% <?php echo $bgpos; ?>; background-image: url('<?php echo base_url(); echo substr($item->image_url, 0, strlen($item->image_url) - 4); echo "_thumb"; echo substr($item->image_url, strlen($item->image_url) - 4, strlen($item->image_url));?>');"></div></div>
                            </a>
                     </div>
                     <div class="kubok">
                         <div class="buble-kubok">
                             <div class="img-kubok">
                                 <img src="<?php echo base_url(); ?>uploads/win/onepos.gif"/>
                                 <img src="<?php echo base_url(); ?>uploads/win/macbook.png"/>
                             </div>
                         </div>
                         <div class="mesto">�����</div>
                         <div class="name-priz">MacBook Pro</div>
                     </div>
                     <div class="name-member">
                         <p><?php echo $item->surname; ?> <?php echo $item->name; ?></p>
                     </div>
                     <div class="ppoll">
                         <div class="buble-ppoll">
                             <div class="count-ppoll">
                                 <span><?php echo $item->count_poll;?></span>
                             </div>
                         </div>
                         <div class="text-ppoll">
                             <?php echo $tpolls; ?>
                         </div>
                     </div>
                     
                     
                 </div>
                 <?php }?>
                 <?php if ($m==2) { ?>
                 <div class="priser2">
                     <div class="photo">
                         <a class="member-link" href="<?php echo base_url(); ?>index.php/action/member/<?php echo $item->idAction; ?>">
                             <div class="bg-img-member"><div class="img" style="background-position: 50% <?php echo $bgpos; ?>; background-image: url('<?php echo base_url(); echo substr($item->image_url, 0, strlen($item->image_url) - 4); echo "_thumb"; echo substr($item->image_url, strlen($item->image_url) - 4, strlen($item->image_url));?>');"></div></div>
                            </a>
                     </div>
                     <div class="kubok">
                         <div class="buble-kubok">
                             <div class="img-kubok">
                                 <img src="<?php echo base_url(); ?>uploads/win/twopos.gif"/>
                                 <img src="<?php echo base_url(); ?>uploads/win/ipad.png"/>
                             </div>
                         </div>
                         <div class="mesto">
                             �����
                         </div>
                         <div class="name-priz">The New IPad</div>
                     </div>
                     <div class="name-member">
                         <p><?php echo $item->surname; ?> <?php echo $item->name; ?></p>
                     </div>
                     <div class="ppoll">
                         <div class="buble-ppoll">
                             <div class="count-ppoll">
                                 <span><?php echo $item->count_poll;?></span>
                             </div>
                         </div>
                         <div class="text-ppoll">
                             <?php echo $tpolls; ?>
                         </div>
                     </div>
                 </div>
                 <?php }?>
                 <?php if ($m==3) { ?>
                 <div class="priser3">
                     <div class="photo">
                         <a class="member-link" href="<?php echo base_url(); ?>index.php/action/member/<?php echo $item->idAction; ?>">
                            <div class="bg-img-member"><div class="img" style="background-position: 50% <?php echo $bgpos; ?>; background-image: url('<?php echo base_url(); echo substr($item->image_url, 0, strlen($item->image_url) - 4); echo "_thumb"; echo substr($item->image_url, strlen($item->image_url) - 4, strlen($item->image_url));?>');"></div></div>
                            </a>
                     </div>
                     <div class="kubok">
                         <div class="buble-kubok">
                             <div class="img-kubok">
                                 <img src="<?php echo base_url(); ?>uploads/win/threepos.gif"/>
                                 <img src="<?php echo base_url(); ?>uploads/win/ifon.png"/>
                             </div>
                         </div>
                         <div class="mesto">
                             �����
                         </div>
                         <div class="name-priz">IPhone 4S</div>
                     </div>
                     <div class="name-member">
                         <p><?php echo $item->surname; ?> <?php echo $item->name; ?></p>
                     </div>
                     <div class="ppoll">
                         <div class="buble-ppoll">
                             <div class="count-ppoll">
                                 <span><?php echo $item->count_poll;?></span>
                             </div>
                         </div>
                         <div class="text-ppoll">
                             <?php echo $tpolls; ?>
                         </div>
                     </div>
                 </div>
                         </div>
                         </td></tr>
                 <?php } ?>
                     
            
     
     
     
     <?php
            }
            else
            {
                
                
            $i++;
            if($i > 4 ){
     ?>
     <tr>
         <td>
             <div class="member-block">
             <a class="member-link" href="<?php echo base_url(); ?>index.php/action/member/<?php echo $item->idAction; ?>">
             <p><?php echo $item->title; ?></p>
             <div class="no-name">
                <div class="bg-img-member"><img src="<?php echo base_url(); echo substr($item->image_url, 0, strlen($item->image_url) - 4); echo "_thumb"; echo substr($item->image_url, strlen($item->image_url) - 4, strlen($item->image_url));?>"/></div>
                <div class="count-poll"><p><?php echo $item->count_poll;?></p></div>
                <p><?php echo $item->slogan; ?></p>
             </div>    
             </a>
             </div>
         </td>
     
    <?php $i=1; }
        else if ($i == 1) {
            ?>
           <tr>
         <td>
             <div class="member-block">
             <a class="member-link" href="<?php echo base_url(); ?>index.php/action/member/<?php echo $item->idAction; ?>">
             <p><?php echo $item->title; ?></p>
             <div class="no-name">
                <div class="bg-img-member"><img src="<?php echo base_url(); echo substr($item->image_url, 0, strlen($item->image_url) - 4); echo "_thumb"; echo substr($item->image_url, strlen($item->image_url) - 4, strlen($item->image_url));?>"/></div>
                <div class="count-poll"><p><?php echo $item->count_poll;?></p></div>
                <p><?php echo $item->slogan; ?></p>
             </div>    
             </a>
             </div>
         </td>  
             
    <?php  
           } 
     else {
         
         ?>
         <td>
            <div class="member-block">
             <a class="member-link" href="<?php echo base_url(); ?>index.php/action/member/<?php echo $item->idAction; ?>">
             <p><?php echo $item->title; ?></p>
             <div class="no-name">
                <div class="bg-img-member"><img src="<?php echo base_url(); echo substr($item->image_url, 0, strlen($item->image_url) - 4); echo "_thumb"; echo substr($item->image_url, strlen($item->image_url) - 4, strlen($item->image_url));?>"/></div>
                <div class="count-poll"><p><?php echo $item->count_poll;?></p></div>
                <p><?php echo $item->slogan; ?></p>
             </div>    
             </a>
             </div>
         </td>
         <?php
         $i++;
     }
     
     if(($i % 4) == 0)
         { 
         ?>
         </tr>
     <?php }
     
     }}
     ?>
    </table>
</div>

