<html><head><title>dfsfdfsfd</title></head>
<body>
    
    <h1>sfdsfdfsd</h1>
    <p>sdfsdf</p>
    <a href="index.php/action">sdfdsffds</a>
        
    </table>
</body></html>