/**
 * Created by 23rd and Walnut
 * www.23andwalnut.com
 * User: Saleem El-Amin
 * Date: 6/8/11
 * Time: 9:39 AM
 */

var myPlaylist = [

    {
        mp3:'/content/mix/Linkin Park - Burn It Down (2012)  (1).mp3',
        title:'Burn It Down (2012)',
        artist:'Linkin Park',
        cover:'/PhpProject1/content/mix/1.png'
    },
    
    {
        mp3:'/content/mix/Lykke Li - I Follow Rivers (The Magician Remix)  (1).mp3',
        title:'I Follow Rivers (The Magician Remix)',
        artist:'Lykke Li',
        cover:'/PhpProject1/content/mix/1.png'
    },
    
    {
        mp3:'/content/mix/Justin Bieber feat. Big Sean - As Long As You Love Me .mp3',
        //oga:'/PhpProject1/contentmix/1.ogg',
        title:'As Long As You Love Me',
        artist:'Justin Bieber feat. Big Sean',
        cover:'/PhpProject1/content/mix/1.png'
    },
    
    {
        mp3:'/content/mix/Far East Movement - Turn Up the Love (Feat. Cover Drive) .mp3',
        title:'Turn Up the Love (Feat. Cover Drive)',
        artist:'Far East Movement',
        cover:'/PhpProject1/content/mix/1.png'
    },
    
    {
        mp3:'content/mix/Nicki Minaj - Pound The Alarm .mp3',
        title:'Pound The Alarm',
        artist:'Nicki Minaj',
        cover:'/PhpProject1/content/mix/1.png'
    },
    
    {
        mp3:'content/mix/Olly Murs feat. Rizzle Kicks - Heart Skips A Beat .mp3',
        title:'Heart Skips A Beat',
        artist:'Olly Murs feat. Rizzle Kicks',
        cover:'/PhpProject1/content/mix/1.png'
    }
    
];
